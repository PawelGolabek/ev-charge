Folder single-file zawiera szablon pracy dyplomowej w jednym pliku main.tex. 
Folder multi-file zawiera szablon pracy dyplomowej podzielony na osobne pliki dla rozdziałów.
Szablony w obu folderach generują dokładnie ten sam plik wynikowy.
